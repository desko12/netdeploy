# NetDeploy - Network Configuration Deployer

## Quick Start

```bash
# Build and run
docker build -t netdeploy .
docker run -d -p 3000:3000 --name netdeploy netdeploy

# Open in browser
http://localhost:3000
```

## Usage

1. Enter your pseudo-XML network configuration in the left panel
2. Click "Deploy" button
3. Watch deployment progress on the right panel

## Pseudo-XML Format

```xml
<config target="router1" host="10.1.1.1" os="eos" user="admin" password="secret">
  <interface name="Loopback0">
    <ip>10.0.0.1/32</ip>
    <state>present</state>
  </interface>
  <bgp as="65001">
    <neighbor ip="10.0.0.2" remote-as="65002">
      <description>ebgp-peer</description>
    </neighbor>
  </bgp>
</config>

<config target="switch1" host="10.1.1.2" os="nxos" user="admin" password="secret">
  <vlan id="100">
    <name>DATA</name>
  </vlan>
</config>
```

## Supported Elements

- `interface` - name, ip, state
- `vlan` - id, name, state
- `bgp` - as (with neighbor sub-element)
- `ospf` - process-id, area
- `network` - ip, area

## Supported OS

- eos (Arista)
- nxos (Cisco Nexus)
- ios (Cisco)
- junos (Juniper)

## Architecture

All-in-one container with embedded Ansible:
- Python 3.12
- Ansible
- SSH client

Direct deployment from container to network equipment.
